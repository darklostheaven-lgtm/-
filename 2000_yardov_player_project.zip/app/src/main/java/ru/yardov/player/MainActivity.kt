package ru.yardov.player

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val Black = Color(0xFF090909)
private val Panel = Color(0xFF191919)
private val Gold = Color(0xFFD6A94F)
private val Muted = Color(0xFF929292)
private val White = Color(0xFFF4F1EB)

data class Track(
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val artwork: ByteArray? = null,
    val remoteArt: String? = null
) {
    val albumKey: String get() = "$artist|$album"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val player = ExoPlayer.Builder(this).build()
        setContent { YardovApp(player) }
    }
    override fun onDestroy() {
        // Player is released by the composable lifecycle owner.
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun YardovApp(player: ExoPlayer) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val tracks = remember { mutableStateListOf<Track>() }
    val favorites = remember { mutableStateListOf<Uri>() }
    var currentUri by remember { mutableStateOf<Uri?>(null) }
    var currentTitle by remember { mutableStateOf("") }
    var currentArtist by remember { mutableStateOf("") }
    var currentArt by remember { mutableStateOf<String?>(null) }
    var currentArtBytes by remember { mutableStateOf<ByteArray?>(null) }
    var tab by remember { mutableStateOf("Треки") }
    var search by remember { mutableStateOf("") }
    var selectedAlbum by remember { mutableStateOf<String?>(null) }
    var fullPlayer by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    var loadingArt by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            if (tracks.none { it.uri == uri }) {
                val retriever = MediaMetadataRetriever()
                val track = try {
                    retriever.setDataSource(context, uri)
                    val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        ?: uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Без названия"
                    val artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                        ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                        ?: "Неизвестный исполнитель"
                    val album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                        ?: "Неизвестный альбом"
                    val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    Track(uri, title, artist, album, ms, retriever.embeddedPicture)
                } finally { runCatching { retriever.release() } }
                tracks.add(track)
            }
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val uri = mediaItem?.localConfiguration?.uri
                currentUri = uri
                tracks.firstOrNull { it.uri == uri }?.let {
                    currentTitle = it.title; currentArtist = it.artist; currentArt = it.remoteArt; currentArtBytes = it.artwork
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }

    LaunchedEffect(player, playing) {
        while (true) {
            if (player.isPlaying) {
                position = player.currentPosition.coerceAtLeast(0)
                duration = player.duration.coerceAtLeast(0)
            }
            delay(500)
        }
    }

    fun playTrack(track: Track) {
        val index = tracks.indexOfFirst { it.uri == track.uri }
        if (index >= 0) {
            player.setMediaItems(tracks.map { MediaItem.fromUri(it.uri) }, index, 0L)
            player.prepare()
            player.play()
            currentUri = track.uri
            currentTitle = track.title
            currentArtist = track.artist
            currentArt = track.remoteArt
            currentArtBytes = track.artwork
            fullPlayer = true
        }
    }

    LaunchedEffect(currentUri, tracks.size) {
        val track = tracks.firstOrNull { it.uri == currentUri } ?: return@LaunchedEffect
        if (track.remoteArt == null && track.artwork == null) {
            loadingArt = true
            val art = lookupArtwork(track.artist, track.album)
            val idx = tracks.indexOfFirst { it.uri == track.uri }
            if (idx >= 0 && art != null) tracks[idx] = tracks[idx].copy(remoteArt = art)
            if (currentUri == track.uri) currentArt = art
            loadingArt = false
        } else { currentArt = track.remoteArt; currentArtBytes = track.artwork }
    }

    val albums = tracks.groupBy { it.albumKey }
    val filtered = tracks.filter {
        val q = search.trim().lowercase()
        (q.isEmpty() || it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q)) &&
        (selectedAlbum == null || it.albumKey == selectedAlbum)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Black, surface = Panel, primary = Gold, onPrimary = Black,
        onBackground = White, onSurface = White, secondary = Gold
    )) {
        Scaffold(
            containerColor = Black,
            bottomBar = {
                if (currentUri != null && !fullPlayer) {
                    MiniPlayer(
                        title = currentTitle, artist = currentArtist, art = currentArt, artBytes = currentArtBytes,
                        playing = playing, position = position, duration = duration,
                        onOpen = { fullPlayer = true },
                        onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                        onNext = { player.seekToNextMediaItem() }
                    )
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Black)) {
                if (fullPlayer) {
                    FullPlayer(
                        title = currentTitle, artist = currentArtist, art = currentArt, artBytes = currentArtBytes,
                        playing = playing, position = position, duration = duration,
                        shuffle = shuffle, repeat = repeat,
                        onBack = { fullPlayer = false },
                        onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                        onPrevious = { player.seekToPreviousMediaItem() },
                        onNext = { player.seekToNextMediaItem() },
                        onSeek = { player.seekTo(it); position = it },
                        onShuffle = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle },
                        onRepeat = { repeat = !repeat; player.repeatMode = if (repeat) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF }
                    )
                } else {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 22.dp, end = 22.dp, top = 20.dp, bottom = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("2000 ЯРДОВ", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                            Text("UNDERGROUND MUSIC PLAYER", color = Gold, fontSize = 12.sp, letterSpacing = 2.sp)
                        }
                        IconButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                            Icon(Icons.Default.Add, null, tint = Gold, modifier = Modifier.size(34.dp))
                        }
                    }
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                        placeholder = { Text("Поиск треков, альбомов, исполнителей", color = Muted) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Gold, unfocusedBorderColor = Color.DarkGray,
                            focusedTextColor = White, unfocusedTextColor = White, cursorColor = Gold
                        )
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        listOf("Треки", "Альбомы", "Исполнители", "Избранное").forEach { name ->
                            Text(name, color = if (tab == name) Gold else Muted,
                                fontWeight = if (tab == name) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.clickable { tab = name; selectedAlbum = null }.padding(vertical = 14.dp, horizontal = 5.dp))
                        }
                    }
                    HorizontalDivider(color = Color(0xFF393939))
                    if (selectedAlbum != null) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { selectedAlbum = null }) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }
                            Text(selectedAlbum!!.substringAfter('|'), color = White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        }
                    }
                    when {
                        tracks.isEmpty() -> EmptyLibrary(onAdd = { picker.launch(arrayOf("audio/*")) })
                        tab == "Альбомы" && selectedAlbum == null -> LazyColumn {
                            items(albums.entries.toList()) { entry ->
                                val first = entry.value.first()
                                AlbumRow(first, entry.value.size) { selectedAlbum = entry.key }
                            }
                        }
                        tab == "Исполнители" -> LazyColumn {
                            items(tracks.distinctBy { it.artist }.sortedBy { it.artist }) { t ->
                                Row(Modifier.fillMaxWidth().clickable { search = t.artist; tab = "Треки" }.padding(18.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Cover(t.remoteArt, t.artwork, 54)
                                    Spacer(Modifier.width(14.dp))
                                    Column { Text(t.artist, color = White, fontWeight = FontWeight.SemiBold); Text("${tracks.count { it.artist == t.artist }} трек(ов)", color = Muted, fontSize = 13.sp) }
                                }
                                HorizontalDivider(color = Color(0xFF242424))
                            }
                        }
                        else -> {
                            val list = if (tab == "Избранное") filtered.filter { favorites.contains(it.uri) } else filtered
                            LazyColumn {
                                items(list, key = { it.uri.toString() }) { track ->
                                    TrackRow(track, favorites.contains(track.uri),
                                        onPlay = { playTrack(track) },
                                        onFavorite = { if (favorites.contains(track.uri)) favorites.remove(track.uri) else favorites.add(track.uri) },
                                        onDelete = { tracks.remove(track); favorites.remove(track.uri) }
                                    )
                                }
                            }
                        }
                    }
                    if (tracks.isNotEmpty()) {
                        Text("${tracks.size} трек(ов) в медиатеке", color = Muted, fontSize = 11.sp,
                            modifier = Modifier.fillMaxWidth().padding(10.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyLibrary(onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.LibraryMusic, null, tint = Gold, modifier = Modifier.size(68.dp))
        Spacer(Modifier.height(16.dp))
        Text("Медиатека пока пуста", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Добавь музыку с устройства — поддерживаются аудиофайлы Android.", color = Muted, modifier = Modifier.padding(vertical = 12.dp))
        Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Gold)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Добавить музыку")
        }
    }
}

@Composable
private fun Cover(url: String?, bytes: ByteArray?, size: Int) {
    if (url != null) AsyncImage(model = url, contentDescription = "Обложка альбома",
        modifier = Modifier.size(size.dp).clip(RoundedCornerShape(9.dp)))
    else if (bytes != null) AsyncImage(model = bytes, contentDescription = "Обложка альбома",
        modifier = Modifier.size(size.dp).clip(RoundedCornerShape(9.dp)))
    else Box(Modifier.size(size.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFF292929)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.MusicNote, null, tint = Gold, modifier = Modifier.size((size / 2).dp))
    }
}

@Composable
private fun TrackRow(track: Track, favorite: Boolean, onPlay: () -> Unit, onFavorite: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onPlay() }.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Cover(track.remoteArt, track.artwork, 58)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${track.artist}  •  ${track.album}", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Gold else Muted) }
        IconButton(onClick = onDelete) { Icon(Icons.Default.DeleteOutline, null, tint = Muted) }
    }
    HorizontalDivider(color = Color(0xFF242424))
}

@Composable
private fun AlbumRow(track: Track, count: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Cover(track.remoteArt, track.artwork, 62); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(track.album, color = White, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("${track.artist} • $count трек(ов)", color = Muted, fontSize = 13.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Gold)
    }
    HorizontalDivider(color = Color(0xFF242424))
}

@Composable
private fun MiniPlayer(
    title: String, artist: String, art: String?, artBytes: ByteArray?, playing: Boolean, position: Long, duration: Long,
    onOpen: () -> Unit, onPlayPause: () -> Unit, onNext: () -> Unit
) {
    Column(Modifier.fillMaxWidth().background(Panel).clickable { onOpen() }.padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Cover(art, artBytes, 46); Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist, color = Muted, fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onClick = onPlayPause) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Gold, modifier = Modifier.size(30.dp)) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White) }
        }
        LinearProgressIndicator(progress = { if (duration > 0) position.toFloat() / duration else 0f },
            modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(4.dp)), color = Gold, trackColor = Color.DarkGray)
    }
}

@Composable
private fun FullPlayer(
    title: String, artist: String, art: String?, artBytes: ByteArray?, playing: Boolean, position: Long, duration: Long,
    shuffle: Boolean, repeat: Boolean, onBack: () -> Unit, onPlayPause: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(Black).padding(horizontal = 22.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.KeyboardArrowDown, null, tint = White, modifier = Modifier.size(32.dp)) }
            Text("СЕЙЧАС ИГРАЕТ", color = Gold, modifier = Modifier.weight(1f), fontSize = 12.sp, letterSpacing = 2.sp)
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, null, tint = Muted) }
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            if (art != null || artBytes != null) AsyncImage(model = art ?: artBytes, contentDescription = "Обложка",
                modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp)))
            else Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(Panel), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Album, null, tint = Gold, modifier = Modifier.size(110.dp))
            }
        }
        Spacer(Modifier.height(30.dp))
        Text(title, color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(artist, color = Muted, fontSize = 16.sp, modifier = Modifier.padding(top = 5.dp))
        Spacer(Modifier.height(22.dp))
        Slider(value = if (duration > 0) position.coerceIn(0, duration).toFloat() else 0f,
            onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..(duration.coerceAtLeast(1).toFloat()),
            colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold, inactiveTrackColor = Color.DarkGray))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(time(position), color = Muted, fontSize = 12.sp); Text(time(duration), color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(15.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Gold else Muted) }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(36.dp)) }
            FilledIconButton(onClick = onPlayPause, modifier = Modifier.size(70.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold)) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Black, modifier = Modifier.size(42.dp))
            }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(36.dp)) }
            IconButton(onClick = onRepeat) { Icon(Icons.Default.Repeat, null, tint = if (repeat) Gold else Muted) }
        }
        Spacer(Modifier.weight(1f))
    }
}

private fun time(ms: Long): String {
    val seconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(seconds / 60, seconds % 60)
}

private suspend fun lookupArtwork(artist: String, album: String): String? = withContext(Dispatchers.IO) {
    if (artist == "Неизвестный исполнитель" || album == "Неизвестный альбом") return@withContext null
    try {
        val term = URLEncoder.encode("$artist $album", "UTF-8")
        val connection = (URL("https://itunes.apple.com/search?term=$term&entity=album&limit=5").openConnection() as HttpURLConnection)
        connection.connectTimeout = 7000
        connection.readTimeout = 7000
        connection.setRequestProperty("User-Agent", "2000YardovPlayer/2.0")
        val json = connection.inputStream.bufferedReader().use { it.readText() }
        connection.disconnect()
        val results = JSONObject(json).optJSONArray("results") ?: return@withContext null
        if (results.length() == 0) return@withContext null
        val wantedArtist = artist.lowercase()
        val wantedAlbum = album.lowercase()
        var best: JSONObject? = null
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val a = item.optString("artistName").lowercase()
            val b = item.optString("collectionName").lowercase()
            if (a.contains(wantedArtist) || wantedArtist.contains(a) || b.contains(wantedAlbum) || wantedAlbum.contains(b)) {
                best = item
                if (a.contains(wantedArtist) && b.contains(wantedAlbum)) break
            }
        }
        (best ?: results.optJSONObject(0))?.optString("artworkUrl100")
            ?.replace("100x100bb", "600x600bb")
    } catch (_: Exception) { null }
}
